# vcu_gst_lib
VCU Gstreamer library constructs video pipeline from enabled elements. It provides API interface to GUI for configuration/control.
